import App from "./App.js";
new App(document.querySelector("#app"));  //타겟값을 줬음